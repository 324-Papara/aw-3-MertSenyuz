namespace Para.Api.Service;

public class CustomService1
{
    public int Counter;
}
public class CustomService2
{
    public int Counter;
}
public class CustomService3
{
    public int Counter;
}
