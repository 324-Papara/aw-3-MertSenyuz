namespace Para.Base.Schema;

public abstract class BaseRequest
{
    
}