namespace Para.Base.Schema;

public abstract class BaseResponse
{
    public long Id { get; set; }
}
