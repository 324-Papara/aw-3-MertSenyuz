using FluentValidation;
using Para.Schema;

namespace Para.Bussiness.Validation.Customer
{
    public class CustomerPhoneRequestValidator : AbstractValidator<CustomerPhoneRequest>
    {
        public CustomerPhoneRequestValidator()
        {
            RuleFor(x => x.Phone)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("Phone number cannot be empty!")
                .MinimumLength(10).WithMessage("Phone number must be at least 10 characters long!");

            RuleFor(x => x.CustomerId)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("Customer ID is required!");

            RuleFor(x => x.CountyCode)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("Country code is required!")
                .MinimumLength(2).WithMessage("Country code must be at least 2 characters long!");
        }
    }
}
