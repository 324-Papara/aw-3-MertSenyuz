using FluentValidation;
using Para.Schema;

namespace Para.Bussiness.Validation.Customer
{
    public class CustomerDetailRequestValidator : AbstractValidator<CustomerDetailRequest>
    {
        public CustomerDetailRequestValidator()
        {
            RuleFor(x => x.CustomerId)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("CustomerId is required")
                .GreaterThan(0).WithMessage("CustomerId must be greater than 0");

            RuleFor(x => x.FatherName)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("FatherName is required");

            RuleFor(x => x.MotherName)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("MotherName is required");

            RuleFor(x => x.EducationStatus)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("EducationStatus is required");

            RuleFor(x => x.MontlyIncome)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("MontlyIncome is required")
                .GreaterThan(0).WithMessage("MontlyIncome must be greater than 0"); // Assuming it's a positive number

            RuleFor(x => x.Occupation)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("Occupation is required");
        }
    }
}
