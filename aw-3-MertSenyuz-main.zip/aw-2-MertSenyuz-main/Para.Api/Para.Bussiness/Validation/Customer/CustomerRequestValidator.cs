﻿using FluentValidation;
using Para.Schema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Para.Bussiness.Validation.Customer
{
    public class CustomerRequestValidator : AbstractValidator<CustomerRequest>
    {

        public CustomerRequestValidator()
        {
  
            RuleFor(x => x.FirstName)
                .Cascade(CascadeMode.StopOnFirstFailure) // Hatalarda dur
                .NotEmpty().WithMessage("FirstName is required!")
                .MinimumLength(2).WithMessage("FirstName must be at least 2 characters!");

            RuleFor(x => x.LastName)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("LastName is required!")
                .MinimumLength(2).WithMessage("LastName must be at least 2 characters!");

            RuleFor(x => x.IdentityNumber)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("IdentityNumber is required!")
                .Length(11).WithMessage("IdentityNumber must be exactly 11 characters!");

            RuleFor(x => x.Email)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("Email is required!")
                .EmailAddress().WithMessage("Valid Email is required!");

            RuleFor(x => x.DateOfBirth)
                .Cascade(CascadeMode.StopOnFirstFailure)
                .NotEmpty().WithMessage("DateOfBirth is required!")
                .Must(BeValidDateOfBirth).WithMessage("DateOfBirth must be a valid date in the past!");
        }
        private bool BeValidDateOfBirth(DateTime dateOfBirth)
        {
            return dateOfBirth < DateTime.Now;
        }
    }
}
